<?php $__currentLoopData = $data['portofolio']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td>
            <?php if($list->status == 1): ?>
            <a class="btn btn-sm btn-text-warning shadowed mr-1 mb-1" href="<?php echo e(url('detail-portofolio/'.$list->trx_id)); ?>"><?php echo e($list->trx_id); ?></a>
            <?php elseif($list->status == 2): ?>
            <a class="btn btn-sm btn-text-danger shadowed mr-1 mb-1" href=""><?php echo e($list->trx_id); ?></a>
            <?php elseif($list->status == 3): ?>
            <a cclass="btn btn-sm btn-text-success shadowed mr-1 mb-1" href=""><?php echo e($list->trx_id); ?></a>
            <?php elseif($list->status == 4): ?>
            <a class="btn btn-sm btn-text-primary shadowed mr-1 mb-1" href=""><?php echo e($list->trx_id); ?></a>
            <?php else: ?>
            <a class="btn btn-sm btn-text-info shadowed mr-1 mb-1" href=""><?php echo e($list->trx_id); ?></a>
            <?php endif; ?>
        </td>
        <td><?php echo e($list->create_date); ?></td>
        <td>
            <?php if($list->status == 1): ?>
            <span class="badge badge-warning">Act</span>
            <?php elseif($list->status == 2): ?>
            <span class="badge badge-danger">Rev</span>
            <?php elseif($list->status == 3): ?>
            <span class="badge badge-success">Ver</span>
            <?php elseif($list->status == 4): ?>
            <span class="badge badge-primary">Apr</span>
            <?php else: ?>
            <span class="badge badge-info">Del</span>
            <?php endif; ?>
        </td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH D:\SERVER APP\htdocs\lara-mobile-ppds\sources\resources\views/portofolio/responsefilter.blade.php ENDPATH**/ ?>