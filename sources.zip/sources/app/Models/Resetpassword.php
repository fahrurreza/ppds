<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Resetpassword extends Model
{
    protected $table = 'reset_password';
}
