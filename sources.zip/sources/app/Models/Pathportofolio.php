<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Pathportofolio extends Model
{
    protected $table = 'path_portofolio';
}
