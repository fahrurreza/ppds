<div class="appBottomMenu">
    <a href="{{route('dashboard')}}" class="item">
        <div class="col">
            <ion-icon name="file-tray-full-outline"></ion-icon>
            <strong>Dashboard</strong>
        </div>
    </a>
    <a href="{{route('list-score')}}" class="item">
        <div class="col">
            <ion-icon name="create-outline"></ion-icon>
            <strong>Daftar Nilai</strong>
        </div>
    </a>
    <a href="{{route('form-portofolio')}}" class="item">
        <div class="col">
            <div class="action-button large">
                <ion-icon name="add-outline"></ion-icon>                    
            </div>
        </div>
    </a>
    
    <a href="{{route('list-portofolio')}}" class="item">
        <div class="col">
            <ion-icon name="document-text-outline"></ion-icon>
            <strong>Daftar Kegiatan</strong>
        </div>
    </a>
    <a href="{{route('profile')}}" class="item">
        <div class="col">
            <ion-icon name="people-outline"></ion-icon>
            <strong>Profile</strong>
        </div>
    </a>
</div>