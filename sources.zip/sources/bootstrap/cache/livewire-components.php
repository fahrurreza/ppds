<?php return array (
  'dashboard.index' => 'App\\Http\\Livewire\\Dashboard\\Index',
  'menu.create' => 'App\\Http\\Livewire\\Menu\\Create',
  'menu.index' => 'App\\Http\\Livewire\\Menu\\Index',
  'product.index' => 'App\\Http\\Livewire\\Product\\Index',
);